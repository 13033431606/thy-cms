define({
  "name": "博客API",
  "version": "0.3.0",
  "description": "供个人博客取值",
  "title": "博客API",
  "url": "http://thycms.tt/public/api",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2019-05-17T15:25:58.100Z",
    "url": "http://apidocjs.com",
    "version": "0.17.7"
  }
});
