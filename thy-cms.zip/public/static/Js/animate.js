$(window).scroll(function() {
    var scroll_top = $(window).scrollTop();
    console.log(scroll_top)

    if (scroll_top > 30) {
        $('.aboutus-3').addClass('animated bounceInUp')
    }
    if (scroll_top > 400) {
        $('.pro-m-top').addClass('animated zoomInUp')
    }
    if (scroll_top > 500) {
        $('.pro-m-mid').addClass('animated bounceIn')
    }
    if (scroll_top > 700) {
        $('.pro-m-bot').addClass('animated bounceIn')
    }
    if (scroll_top > 1206) {
        $('.news-left').addClass('animated fadeInLeftBig')
        $('.news-right').addClass('animated fadeInRightBig')
    }
})