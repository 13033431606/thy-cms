/**
 * @author 汤昊赟
 * 类集
 */

/**
 * 侧边栏sidebar类
 */
class sideBarClass{

    /**
     * @constructor
     */
    constructor(){

    }

    /**
     * 侧边栏展开方法
     *
     * @param {Object} target 点击的目标
     */
    slideToggle(target){
        $(target).toggleClass("father_row_on");
        $(target).siblings(".son_row").slideToggle();
    }

    /**
     * 侧边栏高亮方法
     * @param {Object} target 点击的目标
     */
    judgeActive(target){
        let str='';
        $(".iframe_tab .needShow").each(function () {
            str+=$(this).attr("thy_id");
        });
        $(".son_row").each(function () {
            $(this).removeClass("son_row_on");
            if(str.includes($(this).find("a").attr("thy_id"))){
                $(this).addClass("son_row_on")
            };
        });
    }

    /**
     * 侧边栏展开缓存进度条方法
     *
     * @param {Object} target 进度条目标
     */
    progressBar(target){
        layui.use('element', function(){
            target = layui.element;
        });
    }

    /**
     * 侧边栏清除缓存方法
     *
     * @param {Object} url 清除缓存的方法路径
     */
    temlClear(url){
        $.ajax({
            url:url,
            type:'post',
            success:function (res) {
                console.log(res);
                layui.use('layer', function(){
                        layer.msg('清除成功!');
                    }
                )
            }
        })
    }
}

/**
 * 顶部tab选项卡类
 */
class tabHeaderClass{

    /**
     * @constructor
     */
    constructor(){

    }

    /**
     * 实例swiper类
     */
    tabHeadeSwiper(){
        return new Swiper('.header_tab',{
            slidesPerView: 'auto',
            spaceBetween: 8,
            freeMode:true,
        });
    }

    /**
     * 添加tab选项卡
     * @param {object} aHref ifrmae框架的目标路径
     * @param {string} text 标签名称
     */
    addTab(aHref,text){
        //判断是否存在选项卡
        aHref=aHref[0]["data"];
        // let text=$.trim($(target).text());
        // let aHref=$(target).attr("thy_id");
        if($(".header_tab_div[thy_id='"+aHref+"']").length==0){
            let li=`<li class="header_tab_div swiper-slide" thy_id="${aHref}"><div class="header_tab_close"><i class="layui-icon layui-icon-close"></i></div><div class="header_tab_refresh"><i class="layui-icon layui-icon-refresh
"></i></div><a>${text}</a></li>`;
            this.tabHeadeSwiper().appendSlide(li); //加到tabSwiper的最后
        }
    }

    /**
     * 添加目标框架
     * @param {object} aHref ifrmae框架的目标路径
     * @param {string} aTarget ifrmae框架的名称
     * @param {string} text 标签名称
     */
    addIframe(aHref,text,aTarget){

        $(".iframe_tab_container").removeClass("needShow");
        // let text=$.trim($(target).text());
        // let aHref=$(target).attr("thy_id");
        // let aTarget=$(target).attr("target");
        let aHref2=aHref[0]["data"];
        if($(".iframe_tab_container[thy_id='"+aHref2+"']").length==0){
            let li=`<li class="iframe_tab_container needShow" thy_id="${aHref2}"><iframe class="admin_body" name="${aTarget}" src="${aHref2}" frameborder="0"></iframe></li>`;
            $(".iframe_tab").prepend(li);
        }else{
            tabHeader.toIframe(aHref);
        }
        this.judgeActive();
    }

    /**
     * 侧边栏高亮方法
     * @param {Object} target 点击的目标
     */
    judgeActive(){
        let str='';
        $(".iframe_tab .needShow").each(function () {
            str+=$(this).attr("thy_id");
        });
        //遍历tab选项卡进行添加clss样式
        $(".header_tab_div").each(function () {
            $(this).removeClass("header_tab_div_on");
            if(str.includes($(this).attr("thy_id"))){
                $(this).addClass("header_tab_div_on")
            };
        });
    }

    /**
     * 转向目标框架
     * @param {object} aHref ifrmae框架的目标路径
     */
    toIframe(aHref){
        if(aHref[0]){
            aHref=aHref[0]["data"];
            $(".iframe_tab_container").removeClass("needShow");
            $(".iframe_tab_container[thy_id='"+aHref+"']").addClass("needShow");
            this.judgeActive();
        }
        else {
            return false;
        }

    }

    /**
     * 刷新目标框架
     * @param {Object} target 点击的目标
     */
    refreshIframe(target){
        let aHref=target.attr("thy_id");
        $("iframe[src='"+aHref+"']")[0].contentWindow.location.reload(true);
    }

    /**
     * 关闭目标框架
     * @param {Object} target 点击的目标
     */
    closeIframe(target){
        let aHref=target.attr("thy_id");
        if(target.hasClass("header_tab_div_on")){
            //声明次元素
            let nextTarget=target.next().length>0?target.next():target.prev();
            //移除tab元素
            target.remove();
            //移除ifrmae元素
            $("iframe[src='"+aHref+"']").parent(".iframe_tab_container").remove();
            //跳转至次元素
            aHref=$.parseHTML(nextTarget.attr("thy_id"));
            this.toIframe(aHref);
            this.judgeActive();
        }
        else{
            //移除元素
            target.remove();
            $("iframe[src='"+aHref+"']").parent(".iframe_tab_container").remove();
        }

    }
}


/**
 * 其他杂项方法
 */


