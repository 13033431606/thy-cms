//swiper配置(banner)
var overlap_options={
    speed:800,
    grabCursor : true,
    autoplay : {
        delay:5000,
        disableOnInteraction: false,
    },
    watchSlidesProgress: true,
    lazy: {
        loadPrevNext: true,
    },
    navigation: {
        nextEl: '.swiper-button-next',
        prevEl: '.swiper-button-prev',
    },
    on:{
        init: function() {
            this.myIndex = 1;
        },
        progress: function() {
            for (var i = 0; i < this.slides.length; i++) {
                var slide=this.slides.eq(i);
                var progress = this.slides[i].progress;
                var translate, boxShadow;
                translate = progress * this.width * 0.8;
                // scale = 1 - Math.min(Math.abs(progress * 0.15), 1);
                scale = 1;
                if (i == this.myIndex) {
                    slide.transform('translate3d(' + (translate) + 'px,0,0) scale(' + scale + ')');
                    slide.css({'z-index':0});
                }
            }
        },
        transitionEnd: function() {
            this.myIndex = this.activeIndex;
            for (var i = 0; i < this.slides.length; i++) {
                var slide=this.slides.eq(i);
                slide.transform('');
                slide.css('z-index',1);
            }
        },
        setTransition: function(speed) {
            for (var i = 0; i < this.slides.length; i++) {
                var slide=this.slides.eq(i);
                slide.transition(speed + 'ms');
            }
        }
    },
    loop:true,
    pagination: {
        el: '.banner_dot',
        clickable: true,
    }
};
var interleaveOffset = 1;
var parallax_options={
    loop: true,
    speed: 900,
    watchSlidesProgress: true,
    autoplay : {
        delay:5000,
        disableOnInteraction: false,
    },
    navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev"
    },
    on: {
        progress: function() {
            var swiper = this;
            for (var i = 0; i < swiper.slides.length; i++) {
                var slideProgress = swiper.slides[i].progress;
                var innerOffset = swiper.width * interleaveOffset;
                var innerTranslate = slideProgress * innerOffset;
                swiper.slides[i].querySelector(".slide-inner").style.transform =
                    "translate3d(" + innerTranslate + "px, 0, 0)";
            }
        },
        touchStart: function() {
            var swiper = this;
            for (var i = 0; i < swiper.slides.length; i++) {
                swiper.slides[i].style.transition = "";
            }
        },
        setTransition: function(speed) {
            var swiper = this;
            for (var i = 0; i < swiper.slides.length; i++) {
                swiper.slides[i].style.transition = speed + "ms";
                swiper.slides[i].querySelector(".slide-inner").style.transition =
                    speed + "ms";
            }
        }
    },
    pagination: {
        el: '.banner_dot',
        clickable: true,
    }
};
$(function () {
    if($(".banner_overlap").length>0){
        var swiper = new Swiper('#Banner',overlap_options);
    }
    else if($(".banner_parallax").length>0){
        // 目标元素[slide-inner]

        var swiper = new Swiper('#Banner',parallax_options);
    }
})
