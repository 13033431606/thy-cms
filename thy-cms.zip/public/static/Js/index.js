/**
 * @author 汤昊赟
 * 方法集
 */

//类声明
let sideBar=new sideBarClass();
let tabHeader=new tabHeaderClass();


////事件集合

//检测首页iframe个数,显示默认iframe
function count_iframe(){
    if($(".admin_body").length>1){
        $(".default_iframe").hide();
    }
    else{
        $(".default_iframe").show();
    }
}

//侧边栏展开
$(".father_row").click(function () {
    sideBar.slideToggle($(this));
});

//侧边栏高亮
$(".son_row").click(function () {
    sideBar.judgeActive();
});

//侧边栏缓存调
sideBar.progressBar($("#temp_progress"))



//顶部tab添加
$(".son_row a[target='admin_body']").click(function () {
    let text=$.trim($(this).text());
    let aHref=$.parseHTML($(this).attr("thy_id"));
    let aTarget=$(this).attr("target");
    tabHeader.addTab(aHref,text);
    tabHeader.addIframe(aHref,text,aTarget);

    count_iframe();
});

//切换tab
$(".header_tab").on("click","a",function () {
    let target=$(this).parent(".header_tab_div");
    let aHref=$.parseHTML(target.attr("thy_id"));
    tabHeader.toIframe(aHref);
    sideBar.judgeActive();
});

//刷新目标iframe
$(".header_tab").on("click",".header_tab_refresh",function () {
    let target=$(this).parent(".header_tab_div");
    tabHeader.refreshIframe(target);
});

//关闭目标iframe
$(".header_tab").on("click",".header_tab_close",function () {
    let target=$(this).parent(".header_tab_div");
    tabHeader.closeIframe(target);

    count_iframe();
});






