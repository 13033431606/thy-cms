//获取缩略图盒子宽高后再执行缩放
function DrawImageB(img) {
    var width_img=$(img).parent().width();
    var height_img=$(img).parent().height();
    DrawImage(img, width_img, height_img);
}

function DrawImage(ImgID, width_s, height_s) {
    var image = new Image();
    image.src = ImgID.src;
    if (image.width > 0 && image.height > 0) {
        flag = true;
        if (image.width / image.height <= width_s / height_s) {
            ImgID.width = width_s;
            var height = (image.height * width_s) / image.width;
            ImgID.height = height;
            ImgID.style.marginTop = -(height - height_s)/2 + "px";
        } else {
            ImgID.height = height_s;
            var width = (image.width * height_s) / image.height;
            ImgID.width = width;
            ImgID.style.marginLeft = -(width - width_s)/2 + "px";
        }
    }
}